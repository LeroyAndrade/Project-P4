# Views (ook wel templates)

Hier zet je al je "templates". De templates zorgen voor de uiteindelijke weergave.
De controller haalt de gegevens op via de *Model* laag en geeft deze aan de *View* die ze op het scherm toont.
De views bevatten dus geen ingewikkelde logica. Alleen if, for, foreach e.d.  De view toont alleen de gegevens in de juiste structuur (in HTML, JSON, CSV, PDF)

In dit project wordt een externe template / view engine gebruikt genaamd *Plates*.
[Hier vind je alle documentatie hierover](http://platesphp.com/) 

Lees dat goed door, zodat je weet wat je allemaal kunt doen met de template engine.