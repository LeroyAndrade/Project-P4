<?php $this->layout('website');?>

<?php $this->start('sidebar')?>
<div class="top-10">
	<h3>Top 10 Buren</h3>
	<ol>
		<li>Pieter</li>
		<li>Achmed</li>
		<li>Rosa</li>
		<li>Alper</li>
		<li>Daan</li>
		<li>Sjoerd</li>
		<li>Mo</li>
		<li>Chantal</li>
		<li>Floor</li>
		<li>Duneya</li>
	</ol>
</div>
<?php $this->stop()?>

<h1>Welkom</h1>

<p>Hier komt later veel meer informatie uit de database</p>




