# Includes

In deze directory zet je alle extra PHP bestanden die je nodig hebt in je website, bijvoorbeeld een bestand met functies of een bestand met alle configuratie waarden.

